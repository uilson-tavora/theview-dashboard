# Setup das APIs Reais — The View Dashboard

## Variáveis de ambiente necessárias no Vercel

| Variável | Valor | Status |
|---|---|---|
| GOOGLE_CLIENT_ID | 703727271757-uli1vg5jddihb0ct442qjn56joom36e7.apps.googleusercontent.com | ✅ Pronto |
| GOOGLE_CLIENT_SECRET | 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 | ✅ Pronto |
| GOOGLE_REFRESH_TOKEN | — | ⚠️ Gerar abaixo |
| GOOGLE_ADS_CUSTOMER_ID | 8305935209 | ✅ Pronto |
| GOOGLE_ADS_DEVELOPER_TOKEN | — | ⚠️ Obter abaixo |
| GA4_PROPERTY_ID | 425809468 | ✅ Pronto |
| NEXT_PUBLIC_BASE_URL | https://theview-dashboard.vercel.app | ✅ Pronto |

---

## Passo 1 — Adicionar variáveis no Vercel

1. Acesse vercel.com → theview-dashboard → Settings → Environment Variables
2. Adicione todas as variáveis da tabela acima (exceto as pendentes)

---

## Passo 2 — Obter o GOOGLE_REFRESH_TOKEN

Após o deploy com as variáveis configuradas:

1. Acesse: https://theview-dashboard.vercel.app/api/auth/refresh-token
2. Faça login com a conta Google que tem acesso ao GA4 e Google Ads
3. Copie o refresh_token que aparecer na tela
4. Adicione como variável de ambiente no Vercel: GOOGLE_REFRESH_TOKEN

---

## Passo 3 — Obter o GOOGLE_ADS_DEVELOPER_TOKEN

1. Acesse: ads.google.com
2. Ferramentas → Centro de API
3. Copie o Developer Token
4. Adicione como variável de ambiente no Vercel: GOOGLE_ADS_DEVELOPER_TOKEN

---

## Passo 4 — Redelploy

Após adicionar todas as variáveis, faça um redeploy no Vercel.
Os dados reais começarão a aparecer no dashboard.
